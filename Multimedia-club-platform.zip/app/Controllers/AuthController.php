<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\RoleModel;
use App\Models\AuditLogModel;

class AuthController extends BaseController
{
    protected $userModel;
    protected $roleModel;
    protected $auditLogModel;

    public function __construct()
    {
        $this->userModel     = new UserModel();
        $this->roleModel     = new RoleModel();
        $this->auditLogModel = new AuditLogModel();
    }

    public function login()
    {
        if (session()->get('is_logged_in')) {
            return redirect()->to('/dashboard');
        }

        return view('auth/login', [
            'title' => 'Login Member Portal - Multimedia Club',
        ]);
    }

    public function attemptLogin()
    {
        $loginInput = trim($this->request->getPost('login') ?? '');
        $password   = $this->request->getPost('password') ?? '';

        if (empty($loginInput) || empty($password)) {
            return redirect()->back()->withInput()->with('error', 'Email, Username, atau No HP dan Password wajib diisi.');
        }

        $cleanPhone = preg_replace('/[^0-9]/', '', $loginInput);

        // Search by username, email, or phone
        $builder = $this->userModel->select('users.*, roles.name as role_name, roles.slug as role_slug')
                               ->join('roles', 'roles.id = users.role_id')
                               ->groupStart()
                                   ->where('users.username', $loginInput)
                                   ->orWhere('users.email', $loginInput)
                                   ->orWhere('users.phone', $loginInput);

        if (!empty($cleanPhone) && strlen($cleanPhone) >= 8) {
            $builder->orWhere("REPLACE(REPLACE(REPLACE(REPLACE(users.phone, ' ', ''), '-', ''), '+', ''), '(', '')", $cleanPhone);

            if (str_starts_with($cleanPhone, '628')) {
                $zeroPhone = '08' . substr($cleanPhone, 3);
                $builder->orWhere("REPLACE(REPLACE(REPLACE(REPLACE(users.phone, ' ', ''), '-', ''), '+', ''), '(', '')", $zeroPhone);
            } elseif (str_starts_with($cleanPhone, '08')) {
                $sixtyTwoPhone = '628' . substr($cleanPhone, 2);
                $builder->orWhere("REPLACE(REPLACE(REPLACE(REPLACE(users.phone, ' ', ''), '-', ''), '+', ''), '(', '')", $sixtyTwoPhone);
            }
        }

        $user = $builder->groupEnd()->first();

        if (!$user) {
            $this->auditLogModel->recordLog(null, 'LOGIN_FAILED', "Percobaan login gagal untuk identifier: {$loginInput}");
            return redirect()->back()->withInput()->with('error', 'Email, Username, No HP, atau Password tidak sesuai.');
        }

        if ($user['status'] !== 'active') {
            $this->auditLogModel->recordLog($user['id'], 'LOGIN_BLOCKED', "Akun dalam status {$user['status']}");
            if ($user['status'] === 'left' || $user['status'] === 'keluar') {
                return redirect()->back()->withInput()->with('error', 'Anda keluar ekskul multimedia.');
            }
            return redirect()->back()->withInput()->with('error', 'Akun Anda nonaktif atau ditangguhkan. Silakan hubungi Pembina / Admin.');
        }

        if (!password_verify($password, $user['password_hash'])) {
            $this->auditLogModel->recordLog($user['id'], 'LOGIN_FAILED', 'Password salah');
            return redirect()->back()->withInput()->with('error', 'Username atau password tidak sesuai.');
        }

        // Create Session
        $sessionData = [
            'user_id'      => $user['id'],
            'member_uuid'  => $user['member_uuid'],
            'username'     => $user['username'],
            'email'        => $user['email'],
            'full_name'    => $user['full_name'],
            'nis_nip'      => $user['nis_nip'],
            'class_dept'   => $user['class_dept'],
            'role_id'      => $user['role_id'],
            'role_slug'    => $user['role_slug'],
            'role_name'    => $user['role_name'],
            'avatar'       => $user['avatar'],
            'is_logged_in' => true,
        ];

        session()->set($sessionData);
        $this->auditLogModel->recordLog($user['id'], 'LOGIN_SUCCESS', "User {$user['username']} berhasil login dengan role {$user['role_name']}");

        return redirect()->to('/dashboard')->with('success', "Selamat datang kembali, {$user['full_name']}!");
    }

    public function register()
    {
        if (session()->get('is_logged_in')) {
            return redirect()->to('/dashboard');
        }

        if ($this->settingModel->getSetting('enable_registration', '1') === '0') {
            return redirect()->to('/login')->with('error', 'Pendaftaran akun baru saat ini sedang ditutup oleh Administrator.');
        }

        return view('auth/register', [
            'title' => 'Pendaftaran Anggota Baru - Multimedia Club',
        ]);
    }

    public function attemptRegister()
    {
        if ($this->settingModel->getSetting('enable_registration', '1') === '0') {
            return redirect()->to('/login')->with('error', 'Pendaftaran akun baru saat ini sedang ditutup oleh Administrator.');
        }
        $usernameInput = (string)$this->request->getPost('username');
        if (preg_match('/\s/', $usernameInput)) {
            return redirect()->back()->withInput()->with('error', 'Pendaftaran gagal: Username tidak boleh mengandung spasi! Silakan ganti spasi dengan garis bawah (_) atau titik (.).');
        }

        $rules = [
            'full_name'        => 'required|min_length[3]|max_length[100]',
            'username'         => 'required|regex_match[/^\S+$/]|alpha_numeric_punct|min_length[3]|is_unique[users.username]',
            'email'            => 'required|valid_email|is_unique[users.email]',
            'nis_nip'          => 'required|min_length[4]',
            'class_grade'      => 'required|in_list[X,XI,XII]',
            'class_room'       => 'required|integer|greater_than_equal_to[1]|less_than_equal_to[10]',
            'division'         => 'required|in_list[Broadcasting,Programming]',
            'phone'            => 'required|numeric|min_length[10]',
            'password'         => 'required|min_length[6]',
            'confirm_password' => 'matches[password]',
        ];

        $customErrors = [
            'username' => [
                'regex_match' => 'Username tidak boleh mengandung karakter spasi. Silakan gunakan huruf, angka, garis bawah (_), atau titik (.).',
                'is_unique'   => 'Username tersebut sudah terdaftar, silakan gunakan username lain.',
            ]
        ];

        if (!$this->validate($rules, $customErrors)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        $classGrade = trim($this->request->getPost('class_grade'));
        $classRoom  = trim($this->request->getPost('class_room'));
        $division   = trim($this->request->getPost('division'));
        $classDept  = "{$classGrade} {$classRoom} - {$division}";

        $memberRole = $this->roleModel->getRoleBySlug('member');

        $userId = $this->userModel->insert([
            'member_uuid'   => $this->userModel->generateUuid(),
            'role_id'       => $memberRole['id'] ?? 4,
            'username'      => trim($this->request->getPost('username')),
            'email'         => trim($this->request->getPost('email')),
            'password_hash' => password_hash($this->request->getPost('password'), PASSWORD_BCRYPT),
            'full_name'     => trim($this->request->getPost('full_name')),
            'nis_nip'       => trim($this->request->getPost('nis_nip')),
            'class_dept'    => $classDept,
            'phone'         => trim($this->request->getPost('phone')),
            'qr_version'    => 1,
            'qr_updated_at' => date('Y-m-d H:i:s'),
            'status'        => 'active',
        ]);

        $this->auditLogModel->recordLog($userId, 'REGISTER_SUCCESS', "Anggota baru {$this->request->getPost('full_name')} mendaftar akun");

        return redirect()->to('/login')->with('success', 'Pendaftaran berhasil! Silakan login menggunakan akun baru Anda.');
    }

    public function logout()
    {
        $userId = session()->get('user_id');
        if ($userId) {
            $this->auditLogModel->recordLog($userId, 'LOGOUT', 'User keluar dari sistem');
        }

        session()->destroy();
        return redirect()->to('/login')->with('success', 'Anda telah berhasil keluar dari sistem.');
    }
}
